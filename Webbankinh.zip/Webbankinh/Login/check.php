<?php
include '../Connectdatabase.php';
session_start();
$severname = "localhost";
$username = "root";
$password ="";
$db = "demo";
$u = $_POST['User'];
$p = $_POST['Pass'];
$query = "SELECT * FROM accout WHERE UserName ='$u' AND PassWord='$p'";
echo $query;
$result = mysqli_query($conn,$query);
$count = mysqli_num_rows($result);
if($count==1){
    $_SESSION['acc'] = $u;
    header('location:../index.php');
    
}else{
    echo 'Login Fail';
}