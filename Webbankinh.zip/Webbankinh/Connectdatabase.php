<?php
$conn = mysqli_connect('localhost','root', '', 'product');
if(!$conn)
    {
    die('connect failed :' .mysqli_connect_error());
}
?>


